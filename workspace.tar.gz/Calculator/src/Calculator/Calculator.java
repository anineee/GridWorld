package Calculator;

import java.util.*;

public class Calculator {
	public double evalExpression() {
		double result = 0;
		Stack<double> operand_s;
		Stack<Character> oprerator_s;
		
		return result;
	}
}
