package Helloworld;

public class Helloworld {
	public static void main(String arg[]) {
		System.out.println("Hello, world!");
	}
}
